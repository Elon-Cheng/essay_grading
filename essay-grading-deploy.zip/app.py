from __future__ import annotations

import json
import os
import re
import subprocess
import threading
import uuid
import zipfile
import sys
import time
import accounts
from urllib.parse import urlsplit
from html import escape
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, HTTPException, UploadFile, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).parent.resolve()
DATA = Path(os.getenv('ESSAY_DATA_DIR',str(ROOT / 'data')))
DATA.mkdir(exist_ok=True)
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
def grading_marker() -> str:
    text = (ROOT / "scripts" / "render_grading_docx.py").read_text(encoding="utf-8")
    match = re.search(r'line\.strip\(\) == "([^"]+)"', text)
    if not match:
        raise RuntimeError("无法读取渲染脚本的原文标记")
    return match.group(1)
app = FastAPI(title="Essay Grading Studio", version="0.1.0")
accounts.initialize()
app.include_router(accounts.router)

PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/")

@app.middleware('http')
async def protect_requests(request: Request, call_next):
    if request.method not in ('GET','HEAD','OPTIONS'):
        origin=request.headers.get('origin')
        if request.headers.get('sec-fetch-site')=='cross-site' or (origin and urlsplit(origin).netloc!=request.url.netloc):
            return JSONResponse({'detail':'请求来源不受信任'},status_code=403)
    response=await call_next(request)
    if request.url.path.startswith('/api/') or request.url.path in ('/','/login','/workspace'):
        response.headers['Cache-Control']='no-store'
    if request.url.path in ('/login','/workspace'):
        response.headers['X-Robots-Tag']='noindex, nofollow'
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    return response

@app.get('/login',response_class=HTMLResponse)
def login_page():
    return (ROOT / 'static' / 'login.html').read_text(encoding='utf-8')

@app.get('/workspace',response_class=HTMLResponse)
def workspace_page(user=Depends(accounts.current_user)):
    return (ROOT / 'static' / 'index.html').read_text(encoding='utf-8')

@app.get('/healthz')
def healthz():
    return {'status': 'ok'}

@app.get('/robots.txt', response_class=HTMLResponse)
def robots():
    return HTMLResponse(f"User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /workspace\nDisallow: /login\nSitemap: {PUBLIC_BASE_URL}/sitemap.xml\n", media_type='text/plain')

@app.get('/sitemap.xml', response_class=HTMLResponse)
def sitemap():
    return HTMLResponse(f'''<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>{escape(PUBLIC_BASE_URL)}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url>
</urlset>''', media_type='application/xml')

if (ROOT / "static").exists():
    app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


def paragraphs_from_docx(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    return [
        "".join(t.text or "" for t in p.findall(".//w:t", NS)).strip()
        for p in root.findall(".//w:body/w:p", NS)
        if "".join(t.text or "" for t in p.findall(".//w:t", NS)).strip()
    ]


def write_source_md(docx: Path, out: Path, start: str | None) -> list[str]:
    paragraphs = paragraphs_from_docx(docx)
    if not paragraphs:
        raise ValueError("DOCX 中没有可读取的正文段落")
    chosen = start.strip() if start else paragraphs[0]
    try:
        index = paragraphs.index(chosen)
    except ValueError as exc:
        raise ValueError("未找到指定的作文首段，请检查首段文字是否完全一致") from exc
    essay = paragraphs[index:]
    out.write_text("## Essay\n\n" + "\n\n".join(essay) + "\n", encoding="utf-8")
    return essay


def mock_grading(essay: list[str]) -> str:
    marker = grading_marker()
    parts = [
        "全文综合评价和提升建议：文章基本围绕主题展开，建议进一步补充具体事例和因果解释，使观点更有说服力。",
        "本篇文章打分估计为：18—21分。",
        "| 档次 | 内容 | 语言 | 组织结构 |\n|---|---|---|---|\n| A | 主题明确，细节充分 | 表达准确自然 | 衔接清晰 |\n| B | 基本切题，部分展开 | 有少量错误 | 结构基本完整 |\n| C | 内容较简单 | 错误影响表达 | 组织较弱 |\n| D | 偏题或内容不足 | 错误较多 | 结构混乱 |\n| E | 未完成任务 | 难以理解 | 缺少结构 |",
    ]
    for i, paragraph in enumerate(essay, 1):
        marked = paragraph
        if i == 1 and len(paragraph) > 12:
            target = paragraph.split()[0]
            marked = paragraph.replace(target, f"~~{target}~~{{++{target}++}}", 1)
        parts.extend([
            marker,
            marked,
            "#### 段落点评",
            f"第{i}段能够承担文章的表达任务，内容与前后文基本连贯。建议增加具体信息，说明观点如何由事实得到支持。",
            "#### 语言提升",
            "1. 注意句子之间的连接关系，并优先使用准确、自然的固定搭配。",
            "#### 问题建议",
            "结合本段内容补充一个具体例子，再检查主语和指代是否清晰。",
        ])
    parts.append("#### 全文综合评价和提升建议")
    parts.append("建议围绕中心观点补充细节，完成后通读全文检查句间衔接和时态一致性。")
    return "\n\n".join(parts) + "\n"


def call_openai(source: str) -> str:
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return ""
    try:
        import httpx
        prompt = (ROOT / "SKILL.md").read_text(encoding="utf-8")
        for name in ("scoring-rubric.md", "writing-rubric.md", "teacher-style.md", "output-format.md", "error-taxonomy.md"):
            prompt += "\n\n" + (ROOT / "references" / name).read_text(encoding="utf-8")
        body = {
            "model": os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            "input": [{"role": "system", "content": prompt}, {"role": "user", "content": source}],
        }
        response = httpx.post("https://api.openai.com/v1/responses", headers={"Authorization": f"Bearer {key}"}, json=body, timeout=120)
        response.raise_for_status()
        data = response.json()
        text = data.get("output_text") or ""
        if not text:
            for item in data.get("output", []):
                for content in item.get("content", []):
                    if content.get("type") in ("output_text", "text"):
                        text += content.get("text", "")
        return text
    except Exception:
        return ""


def run_job(job_id: str, start: str | None) -> None:
    folder = DATA / job_id
    meta = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
    try:
        meta.update(status="running", stage="extracting")
        (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        essay = write_source_md(folder / "source.docx", folder / "source.md", start)
        source = (folder / "source.md").read_text(encoding="utf-8")
        meta.update(stage="grading")
        (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        grading = call_openai(source) or mock_grading(essay)
        (folder / "grading.md").write_text(grading, encoding="utf-8")
        meta.update(stage="rendering")
        (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        subprocess.run([sys.executable, str(ROOT / "scripts" / "render_grading_docx.py"), "--source-docx", str(folder / "source.docx"), "--source-md", str(folder / "source.md"), "--grading-md", str(folder / "grading.md"), "--output-docx", str(folder / "graded.docx")], check=True, capture_output=True, text=True)
        meta.update(status="succeeded", stage="done")
    except Exception as exc:
        meta.update(status="failed", stage="error", error=str(exc))
    (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    if meta.get("user_id"):
        accounts.audit(meta["user_id"], meta["status"], meta.get("filename", job_id))


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    page=(ROOT / "static" / "landing.html").read_text(encoding="utf-8")
    return page.replace('rel="canonical" href="/"',f'rel="canonical" href="{escape(PUBLIC_BASE_URL,quote=True)}/"')


@app.post("/api/essays")
async def create_essay(background: BackgroundTasks, file: UploadFile = File(...), start: str | None = Form(None), user=Depends(accounts.current_user)) -> dict[str, Any]:
    if not file.filename or not file.filename.lower().endswith(".docx"):
        raise HTTPException(400, "仅支持 .docx 文件")
    job_id = uuid.uuid4().hex
    folder = DATA / job_id
    folder.mkdir()
    content = await file.read()
    if len(content) > 10 * 1024 * 1024:
        raise HTTPException(413, "文件不能超过 10 MB")
    (folder / "source.docx").write_bytes(content)
    meta = {"id": job_id, "filename": file.filename, "status": "queued", "stage": "queued", "user_id": user["id"]}
    (folder / "meta.json").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    with accounts.database() as db:
        db.execute("INSERT INTO jobs(id,user_id,filename,start,created) VALUES(?,?,?,?,?)", (job_id,user["id"],file.filename,start,time.time()))
    accounts.audit(user["id"], "upload", file.filename)
    background.add_task(run_job, job_id, start)
    return meta


@app.get("/api/essays/{job_id}")
def get_essay(job_id: str, user=Depends(accounts.current_user)) -> dict[str, Any]:
    accounts.owned_job(job_id,user)
    path = DATA / job_id / "meta.json"
    if not path.exists():
        raise HTTPException(404, "任务不存在")
    return json.loads(path.read_text(encoding="utf-8"))


@app.get("/api/essays")
def list_essays(user=Depends(accounts.current_user)) -> list[dict[str, Any]]:
    items = []
    for path in DATA.glob("*/meta.json"):
        try:
            item=json.loads(path.read_text(encoding="utf-8"))
            if item.get("user_id")==user["id"]:
                items.append(item)
        except (OSError, json.JSONDecodeError):
            continue
    return sorted(items, key=lambda item: item.get("id", ""), reverse=True)


@app.post("/api/essays/{job_id}/retry")
def retry_essay(job_id: str, background: BackgroundTasks, user=Depends(accounts.current_user)) -> dict[str, Any]:
    job=accounts.owned_job(job_id,user)
    folder = DATA / job_id
    meta_path = folder / "meta.json"
    if not meta_path.exists() or not (folder / "source.docx").exists():
        raise HTTPException(404, "任务不存在")
    meta = json.loads(meta_path.read_text(encoding="utf-8"))
    if meta['status'] != 'failed':
        raise HTTPException(409,'仅可重试失败的任务')
    meta.update(status="queued", stage="queued", error=None)
    meta_path.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    accounts.audit(user["id"], "retry", meta.get("filename",""))
    background.add_task(run_job, job_id, job['start'])
    return meta


@app.get("/api/essays/{job_id}/preview")
def preview(job_id: str, user=Depends(accounts.current_user)) -> dict[str, str]:
    job=accounts.owned_job(job_id,user)
    accounts.audit(user['id'],'preview',job['filename'])
    folder = DATA / job_id
    if not (folder / "meta.json").exists():
        raise HTTPException(404, "任务不存在")
    return {"source": (folder / "source.md").read_text(encoding="utf-8") if (folder / "source.md").exists() else "", "grading": (folder / "grading.md").read_text(encoding="utf-8") if (folder / "grading.md").exists() else ""}


@app.get("/api/essays/{job_id}/download")
def download(job_id: str, user=Depends(accounts.current_user)) -> FileResponse:
    job=accounts.owned_job(job_id,user)
    path = DATA / job_id / "graded.docx"
    if not path.exists():
        raise HTTPException(404, "批改文件尚未生成")
    accounts.audit(user["id"], "download", job['filename'])
    return FileResponse(path, filename=f"graded-{job_id[:8]}.docx", media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
