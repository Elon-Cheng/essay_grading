$ErrorActionPreference = 'Stop'
$siteRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
Set-Location -LiteralPath $siteRoot
foreach ($line in Get-Content -LiteralPath (Join-Path $siteRoot '.env')) {
    if ($line.Trim() -and -not $line.Trim().StartsWith('#')) {
        $pair = $line.Split('=', 2)
        if ($pair.Count -ne 2) { throw 'Invalid environment setting' }
        [Environment]::SetEnvironmentVariable($pair[0].Trim(), $pair[1], 'Process')
    }
}
$env:ESSAY_DATA_DIR = Join-Path $siteRoot 'data'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUNBUFFERED = '1'
$process = Start-Process -FilePath "$siteRoot\.venv\Scripts\python.exe" -ArgumentList '-m', 'uvicorn', 'app:app', '--host', '0.0.0.0', '--port', '80', '--no-proxy-headers' -WorkingDirectory $siteRoot -WindowStyle Hidden -RedirectStandardOutput "$siteRoot\logs\stdout.log" -RedirectStandardError "$siteRoot\logs\stderr.log" -Wait -PassThru
exit $process.ExitCode
